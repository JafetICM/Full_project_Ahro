<!-- C:\Users\dell\nombre-proyecto\frontend-vue/src/components/InicioSYSCOM.vue -->
<template>
  <div>    
<!-- Hero -->
    <section class="hero" id="inicio">
      <div class="hero-content">
        <h1>Catálogo Electrónico</h1>
        <p>Explora el catálogo electrónico de SYSCOM</p>
      </div>
    </section>

    <!-- Main Welcome -->
    <section class="main-welcome" id="bienvenida">
      <div class="container">
        <h1>Bienvenido al catálogo SYSCOM</h1>
        <h2>Productos de telecomunicaciones y seguridad</h2>
        <p>Encuentra lo que necesitas en un solo lugar.</p>
      </div>
    </section>

    <!-- About -->
    <section class="about-section" id="nosotros">
      <div class="container">
        <h2>¿Qué es SYSCOM?</h2>
        <p>SYSCOM es proveedor líder de soluciones en telecomunicaciones, redes, videovigilancia, energía, automatización y más.</p>
        <p>Consulta nuestro catálogo completo con miles de productos especializados.</p>
      </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
      <div class="company-info">
        <h3>SYSCOM Distribuidor</h3>
        <p>Calle Ejemplo 123, Mérida México</p>
        <p>+52 000 000 0000</p>
      </div>
      <div class="copyright">
        &copy; 2025 SYSCOM - Todos los derechos reservados.
      </div>
    </footer>
  </div>
</template>


