<?php
//C:\Users\dell\nombre-proyecto/backen-laravel/config/services.php
return [

    'syscom' => [
        'url' => env('SYSCOM_API_URL'),
        'token' => env('SYSCOM_ACCESS_TOKEN'),
        'client_id' => env('SYSCOM_CLIENT_ID'),
        'client_secret' => env('SYSCOM_CLIENT_SECRET'),
    ],
];
